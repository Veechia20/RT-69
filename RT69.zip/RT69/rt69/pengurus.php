<?php
$pengurus = [
    [
        "nama" => "Rayhan Ilham Alfianto",
        "img" => "images/ryhn.jpg",
        "instagram" => "https://www.instagram.com/rayhan_ilham/",
        "jabatan" => "Ketua RT69"
    ],
    [
        "nama" => "Diaz",
        "img" => "images/dias.jpg",
        "instagram" => "https://www.instagram.com/mdiazp20_/",
        "jabatan" => "Wakil"
    ],
    [
        "nama" => "Janeta Tefa Putra",
        "img" => "images/janet.jpg",
        "instagram" => "https://www.instagram.com/janetaputra/",
        "jabatan" => "Sekretariat"
    ],
    [
        "nama" => "Bimo Febriyanto",
        "img" => "images/bimo.jpg",
        "instagram" => "https://www.instagram.com/bimofebri_/",
        "jabatan" => "Anggota"
    ],
    [
        "nama" => "Agung Budi Santoso",
        "img" => "images/agung.jpg",
        "instagram" => "https://www.instagram.com/agungbudisants/",
        "jabatan" => "Anggota"
    ],
    [
        "nama" => "Naomi Damelina",
        "img" => "images/nomi.jpg",
        "instagram" => "https://www.instagram.com/nomidmln_/",
        "jabatan" => "Anggota"
    ],
    [
        "nama" => "Ayu Djaenah",
        "img" => "images/ayu.jpg",
        "instagram" => "https://www.instagram.com/honey3pie/",
        "jabatan" => "Anggota"
    ],
    [
        "nama" => "Kevin Apriliano",
        "img" => "images/kevin.jpg",
        "instagram" => "https://www.instagram.com/notabmf/",
        "jabatan" => "Anggota"
    ],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pengurus RT 69</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Daftar Pengurus RT 69</h1>
</header>

<nav>
    <ul>
        <li><a href="index.php">Beranda</a></li>
        <li><a href="pengurus.php" class="active">Daftar Pengurus</a></li>
        <li><a href="agenda.php">Agenda Kegiatan</a></li>
        <li><a href="keluhan.php">Form Keluhan</a></li>
        <li><a href="daftar_warga.php">Daftar Warga Baru</a></li>
    </ul>
</nav>

<main>
    <section>
        <h2>Tim inti pengurus RT 69</h2>
        <p class="agenda-intro">Kenalan sama orang-orang hebat dan asik di balik sistem RT paling asik ini!</p>
        <div class="pengurus-list">
            <?php foreach ($pengurus as $p): ?>
                <div class="pengurus-item">
                    <div class="pengurus-img-wrap">
                        <img src="<?= htmlspecialchars($p['img']) ?>" alt="Foto <?= htmlspecialchars($p['nama']) ?>">
                        <span class="jabatan"><?= htmlspecialchars($p['jabatan']) ?></span>
                    </div>
                    <div class="pengurus-info">
                        <h3>
                            <a href="<?= htmlspecialchars($p['instagram']) ?>" class="pengurus-link" target="_blank">
                                <?= htmlspecialchars($p['nama']) ?>
                            </a>
                        </h3>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</main>

<footer>
    <p>&copy; 2025 RT 69. All rights reserved.</p>
</footer>

</body>
</html>

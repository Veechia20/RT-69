<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "RT69";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// ======= PERBAIKAN: proses simpan dibungkus dalam tag PHP =======
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $nik = $_POST['nik'];
    $telepon = $_POST['telepon'];

    if (!empty($nama) && !empty($nik) && !empty($telepon)) {
        $query_insert = "INSERT INTO warga (nama, nik, telepon) VALUES ('$nama', '$nik', '$telepon')";
        mysqli_query($conn, $query_insert);
    }
}
?>



<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Pendaftaran Warga Baru RT 69</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef6fc;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3f75b5;
            color: white;
            text-align: center;
            padding: 20px;
        }

        nav {
            background-color: #86e082;
            padding: 10px 0;
            text-align: center;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: black;
            font-weight: bold;
        }

        .container {
            display: flex;
            justify-content: center;
            gap: 40px;
            padding: 30px;
            flex-wrap: wrap;
        }

        section {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 400px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
        }

        input, button {
            padding: 10px;
            margin-top: 5px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            background-color: #3f75b5;
            color: white;
            margin-top: 15px;
            cursor: pointer;
        }

        button:hover {
            background-color: #345d90;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 14px;
        }

        th, td {
            border: 1px solid #999;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #eee;
        }

        th:nth-child(1) { width: 40px; }
        th:nth-child(2) { width: 120px; }
        th:nth-child(3) { width: 150px; }
        th:nth-child(4) { width: 100px; }

        footer {
            text-align: center;
            padding: 15px;
            background-color: #3f75b5;
            color: white;
        }
    </style>
</head>
<body>
    <header>
        <h1>Form Pendaftaran Warga Baru RT 69</h1>
    </header>
    <nav>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="pengurus.php">Daftar Pengurus</a></li>
            <li><a href="agenda.php">Agenda Kegiatan</a></li>
            <li><a href="keluhan.php">Form Keluhan</a></li>
            <li><a href="daftar_warga.php">Daftar Warga Baru</a></li>
        </ul>
    </nav>

    <main>
        <div class="container">
            <!-- Form Pendaftaran -->
            <section>
                <h2>Pendaftaran Warga Baru</h2>
                <form action="" method="POST">
                    <label for="nama">Nama:</label>
                    <input type="text" name="nama" required>

                    <label for="nik">NIK:</label>
                    <input type="text" name="nik" required>

                    <label for="telepon">No Telepon:</label>
                    <input type="text" name="telepon" required>

                    <button type="submit">Daftar</button>
                </form>
            </section>

            <!-- Tabel Data Warga -->
           <section>
    <h2>Data Warga</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>NIK</th>
                <th>No Telepon</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $query = "SELECT * FROM warga ORDER BY id DESC";
            $result = mysqli_query($conn, $query);

            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$no}</td>
                            <td>{$row['nama']}</td>
                            <td>{$row['nik']}</td>
                            <td>{$row['telepon']}</td>
                          </tr>";
                    $no++;
                }
            } else {
                echo "<tr><td colspan='4'>Belum ada data warga</td></tr>";
            }
            ?>
        </tbody>
    </table>
</section>

        </div>
    </main>

    <footer>
        <p>&copy; 2025 RT 69. All rights reserved.</p>
    </footer>
</body>
</html>

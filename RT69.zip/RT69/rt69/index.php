<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi RT 69</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Selamat Datang di Sistem Informasi RT 69</h1>
        <p>Kami adalah kelompok ramah keluarga di RT 69!</p>
    </header>
    <nav>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="pengurus.php">Daftar Pengurus</a></li>
            <li><a href="agenda.php">Agenda Kegiatan</a></li>
            <li><a href="keluhan.php">Form Keluhan</a></li>
            <li><a href="daftar_warga.php">Daftar Warga Baru</a></li>
        </ul>
    </nav>
    <main>
        <section>
            <h2>Tentang RT 69</h2>
            <p> RT 69 adalah kelompok yang dirancang sebagai bagian dari tugas proyek mata kuliah kami. 
                Meskipun hanya fiktif, kami membangun sistem ini dengan pendekatan nyata memiliki struktur kepengurusan, agenda kegiatan, serta wadah aspirasi layaknya RT sungguhan.<br><br>
				
				Lewat proyek ini, kami belajar mengembangkan sistem informasi sederhana berbasis web yang bertujuan mempermudah komunikasi antar warga dan pengurus. 
				RT 69 bukan cuma sekadar RT — ini adalah tempat di mana tawa, curhat! Di sini, warga fiktif kami saling dukung, saling sapa, dan (kadang) saling rebutan kursi <br><br>
				
				Oiyaa,untuk para warga yang lagi suntuk nugas?  Punya uneg-uneg soal agenda kegiatan? Atau sekadar pengin cerita soal hidup dan cinta? Tenang, kami punya andalan: 
				<strong>hubungi Ketua RT kami, RAYHAN ILHAM ALFIANTO</strong> — spesialis senyum manis dan kuping anti-bising.<br><br>
			</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 RT 69. All rights reserved.</p>
    </footer>
</body>
</html>
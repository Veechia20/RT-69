<?php
$kegiatan = [
	["gambar" => "images/pengurus.jpg"],
    ["gambar" => "images/makan_makan.jpg"],
    ["gambar" => "images/bukber.jpg"],
    ["gambar" => "images/makrab.jpg"],
	["gambar" => "images/liburan.jpg"],
	["gambar" => "images/ngumpul_bareng.jpg"],
];
$vidio_kegiatan = [
	"vidio/bakar-bakar.mp4",
    "vidio/liburan2.mp4",
    "vidio/liburan3.mp4"
];	
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda Kegiatan RT 69</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Agenda Kegiatan RT 69</h1>
</header>

<nav>
    <ul>
        <li><a href="index.php">Beranda</a></li>
        <li><a href="pengurus.php">Daftar Pengurus</a></li>
        <li><a href="agenda.php" class="active">Agenda Kegiatan</a></li>
        <li><a href="keluhan.php">Form Keluhan</a></li>
        <li><a href="daftar_warga.php">Daftar Warga Baru</a></li>
    </ul>
</nav>

<main>
    <section>
        <h2>Kegiatan Seru di RT 69</h2>
        <p class="agenda-intro">
            Walau fiktif, semangat kami nyata! Inilah rangkaian kegiatan RT 69 yang selalu dinanti-nanti warga virtual kami.
        </p>
        <div class="agenda-slider-no-desc">
            <?php foreach ($kegiatan as $k): ?>
                <div class="agenda-slide-no-desc">
                    <img src="<?= htmlspecialchars($k['gambar']) ?>" alt="Kegiatan RT 69">
                </div>
            <?php endforeach; ?>
        </div>
		<h2>Vidio Kegiatan RT69</h2>
		<div class="vidio-container">
			<?php foreach ($vidio_kegiatan as $video): ?>
			 <video controls class="video-kegiatan">
				<source src="<?= htmlspecialchars($video) ?>" type="video/mp4">
				Browser kamu tidak mendukung tag video.
        </video>
    <?php endforeach; ?>
		</div>	
    </section>
</main>

<footer>
    <p>&copy; 2025 RT 69. All rights reserved.</p>
</footer>

</body>
</html>

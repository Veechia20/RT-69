<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Keluhan Warga RT 69</title>
    <link rel="stylesheet" href="style.css">
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #e9f3fc;
        margin: 0;
        padding: 0;
    }

    header {
        background-color: #3f75b5;
        color: white;
        text-align: center;
        padding: 20px 0;
    }

    nav {
        background-color: #86e082;
        padding: 10px 0;
        text-align: center;
    }

    nav ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    nav ul li {
        display: inline;
        margin: 0 15px;
    }

    nav ul li a {
        text-decoration: none;
        color: black;
        font-weight: bold;
    }

    .container {
        display: flex;
        justify-content: center;
        gap: 40px;
        padding: 30px;
    }

    section {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
        width: 350px;
    }

    form {
        display: flex;
        flex-direction: column;
    }

    label {
        margin-top: 10px;
        font-weight: bold;
    }

    input, textarea, button {
        padding: 8px;
        margin-top: 5px;
        font-size: 14px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    button {
        background-color: #3f75b5;
        color: white;
        margin-top: 15px;
        cursor: pointer;
    }

    button:hover {
        background-color: #345d90;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
        margin-top: 10px;
    }

    th, td {
        border: 1px solid #aaa;
        padding: 8px 10px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
        width: auto;
    }

    th:nth-child(1) { width: 40px; }
    th:nth-child(2) { width: 100px; }
    th:nth-child(3) { width: 200px; }

    footer {
        text-align: center;
        padding: 15px;
        background-color: #3f75b5;
        color: white;
    }
</style>

</head>
<body>

<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$password = "";
$database = "RT69";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>

    <header>
        <h1>Form Keluhan Warga RT 69</h1>
    </header>
    <nav>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="pengurus.php">Daftar Pengurus</a></li>
            <li><a href="agenda.php">Agenda Kegiatan</a></li>
            <li><a href="keluhan.php">Form Keluhan</a></li>
            <li><a href="daftar_warga.php">Daftar Warga Baru</a></li>
        </ul>
    </nav>

    <main>
        <div class="container">
            <!-- Form Input -->
            <section>
                <h2>Input Keluhan</h2>
                <form action="process_keluhan.php" method="POST">
                    <label for="nama">Nama:</label>
                    <input type="text" id="nama" name="nama" required>
                    
                    <label for="keluhan">Keluhan:</label>
                    <textarea id="keluhan" name="keluhan" rows="5" required></textarea>
                    
                    <button type="submit">Kirim Keluhan</button>
                </form>
            </section>

            <!-- Tabel Hasil -->
            <section>
                <h2>Daftar Keluhan</h2>
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Keluhan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
$no = 1;
$query = "SELECT * FROM keluhan ORDER BY id DESC";
$result = mysqli_query($conn, $query);

// Cek jika query gagal
if (!$result) {
    echo "<tr><td colspan='3'>Gagal mengambil data: " . mysqli_error($conn) . "</td></tr>";
} else {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>" . $no++ . "</td>
                <td>" . htmlspecialchars($row['nama']) . "</td>
                <td>" . htmlspecialchars($row['keluhan']) . "</td>
              </tr>";
    }
}
?>

                    </tbody>
                </table>
            </section>
        </div>
    </main>

    <footer>
        <p>&copy; 2025 RT 69. All rights reserved.</p>
    </footer>
</body>
</html>
